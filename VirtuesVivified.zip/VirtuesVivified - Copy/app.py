from flask import Flask, render_template, request, Response
import cohere
import os
import datetime
import requests
import markdown

app = Flask(__name__)

# Initialize Cohere client with your API key
cohere_client = cohere.Client('')# Add your cohere API key here

LESSONS_TEXT_FOLDER = 'lessons_text'

def load_lesson_text(lesson_name):
    file_path = os.path.join(LESSONS_TEXT_FOLDER, f'{lesson_name}.txt')
    print(f"Loading file from: {file_path}")  # Debugging print

    if os.path.exists(file_path):
        with open(file_path, 'r',  encoding='utf-8') as f:
            return f.read()
    else:
        print(f"File not found: {file_path}")  # Debugging print
        return 'Lesson text not found.'

# Predefined lessons with external URLs for websites (now with multiple URLs)
lessons = {
    'Kindness': {
        'text': "Kindness is the act of being friendly, generous, and considerate. It means showing concern for others, especially those who are in need.",
        'urls': [
            'https://www.randomactsofkindness.org/kindness-stories/3919-2-for-a-shirt',
            'https://en.wikipedia.org/wiki/Kindness',
            'https://static1.squarespace.com/static/590be125ff7c502a07752a5b/t/5aefb98baa4a9960d84abf6d/1525660044544/Miller%2C+James+Russell%2C+The+Beauty+of+Kindness.pdf',
            'https://smileymovement.org/news/random-acts-of-kindness',
        ],  
        'story': 'Once upon a time, there was a boy who helped an old lady cross the road...',
        'video_url': 'https://www.youtube.com/embed/NOdwlJSavkc'
    },

    'Honesty': {
        'text': "Honesty is being truthful, trustworthy, and fair in all situations. It means not deceiving or lying to others.",
        'urls': [
            'https://en.wikipedia.org/wiki/Honesty',
            'https://www.vivekananda.net/PDFBooks/bhagavadgitawith00londiala.pdf',
            'https://www.ohmytales.com/h/-the-magical-power-of-honesty-/',
            'https://freestoriesforkids.com/children/stories-and-tales/day-stork-stole-wedding',
        ],  
        'story': 'There was once a young girl who found a wallet and returned it to its rightful owner, even though she could have kept the money.',
        'video_url': 'https://www.youtube.com/embed/hkUSjaGiGzk'
    },

    'Courage': {
        'text': "Courage is the ability to face fear, danger, or difficulty with bravery and strength. It involves standing up for what is right, even when it’s hard.",
        'urls': [
            'https://www.ohmytales.com/h/-the-quest-for-the-hidden-map-/',
            'https://www.ohmytales.com/h/-the-midnight-code-mystery-/',
            'https://ia601703.us.archive.org/29/items/dli.ernet.79433/79433-Courage.pdf',
            'https://en.wikipedia.org/wiki/Courage',
        ],  
        'story': 'In a small village, a young boy stood up to a bully who had been tormenting his classmates, showing immense courage.',
        'video_url': 'https://www.youtube.com/embed/AW3klebbNYY'
    },

    'Responsibility': {
        'text': "Responsibility means being accountable for one's actions, fulfilling duties, and taking care of things entrusted to you.",
        'urls': [
            'https://www.ohmytales.com/h/-cloud-chasers-adventure-/',
            'https://www.mdos.si/wp-content/uploads/2018/04/defining-corporate-social-responsibility.pdf',
            'https://en.wikipedia.org/wiki/Collective_responsibility',
            'https://www.thegoodproject.org/good-blog/tag/responsibility',
        ],  
        'story': 'A young girl took responsibility for her little brother when their parents went on vacation, ensuring he was safe and well-cared for.',
        'video_url': 'https://www.youtube.com/embed/b1CC2je5d5s'
    },

    'Perseverance': {
        'text': "Perseverance is the ability to keep going in spite of challenges and setbacks. It involves not giving up when things get tough.",
        'urls': [
            'https://shahanedostaliyeva.wordpress.com/wp-content/uploads/2018/07/angela-duckworth-grit.pdf',
            'https://en.wikipedia.org/wiki/Perseveration',
            'https://www.theperseveranceproject.com/',
            'https://freestoriesforkids.com/children/stories-and-tales/cockerel-duck-and-mermaids',
        ],  
        'story': 'Despite facing many obstacles, a young athlete continued to train every day, eventually winning a national championship.',
        'video_url': 'https://www.youtube.com/embed/H14bBuluwB8'
    },

    'Gratitude': {
        'text': "Gratitude is recognizing and appreciating the good things in life. It involves being thankful for what you have and showing appreciation.",
        'urls': [
            'https://en.wikipedia.org/wiki/Gratitude',
            'https://greatergood.berkeley.edu/topic/gratitude',
            'https://colettelafia.com/wp-content/uploads/21-Days-of-Gratitude-eBook-1.pdf',
            'https://www.thetappingsolution.com/blog/short-lesson-gratitude/',
        ],  
        'story': 'A young boy woke up every day and wrote down three things he was grateful for, which made him realize how lucky he was.',
        'video_url': 'https://www.youtube.com/embed/UtBsl3j0YRQ'
    },

    'Empathy': {
        'text': "Empathy is the ability to understand and share the feelings of others. It involves stepping into someone else’s shoes and being compassionate.",
        'urls': [
            'https://www.empathyset.com/blog',
            'https://en.wikipedia.org/wiki/Empathy',
            'https://www.ohmytales.com/h/-the-lighthouse-secret-/',
            'https://www.romankrznaric.com/wp-content/uploads/2011/12/Empathy%20and%20the%20Art%20of%20Living%20200907.pdf',
        ],  
        'story': 'A young girl noticed her classmate was feeling sad and took time to sit with her and talk, showing kindness and understanding.',
        'video_url': 'https://www.youtube.com/embed/baHrcC8B4WM'
    },

    'Teamwork': {
        'text': "Teamwork is the combined effort of a group to achieve a common goal. It involves collaboration, communication, and supporting each other.",
        'urls': [
            'https://www.atlassian.com/blog/teamwork/the-importance-of-teamwork',
            'https://ririro.com/the-rescue-of-red-top/#google_vignette',
            'https://en.wikipedia.org/wiki/Teamwork',
            'https://2012books.lardbucket.org/pdfs/an-introduction-to-business-v2.0/s12-teamwork-and-communications.pdf',
        ],  
        'story': 'A team of workers came together to finish a community project, helping each other to reach their shared goal.',
        'video_url': 'https://www.youtube.com/embed/UwsMogSQmYI'
    },

    'Self-Discipline': {
        'text': "Self-discipline is the ability to control one's emotions, behaviors, and actions in the face of temptations and impulses.",
        'urls': [
            'https://yogastories.co.uk/2010/09/17/fish-and-rice-a-story-about-self-control-and-gratitude-for-children-age-6-10-years/',
            'https://pdfdrive.com.co/wp-content/pdfh/the-power-of-discipline-PDFdrive.com.co.pdf',
            'http://dspace.vnbrims.org:13000/jspui/bitstream/123456789/4251/1/Daily%20Self-Discipline%20Everyday%20Habits%20and%20Exercises%20to%20Build%20Self-Discipline%20and%20Achieve%20Your%20Goals.pdf',
            'https://en.wikipedia.org/wiki/Discipline',
        ],  
        'story': 'A young student stuck to a strict study schedule, despite the temptation to procrastinate, and achieved excellent results.',
        'video_url': 'https://www.youtube.com/embed/tTb3d5cjSFI'
    }
}

# Load lesson texts from individual files
for lesson in lessons:
    lessons[lesson]['text'] = load_lesson_text(lesson)

# Directory to store diary entries
DIARY_FOLDER = "diary_entries"
if not os.path.exists(DIARY_FOLDER):
    os.makedirs(DIARY_FOLDER)

# Proxy server to bypass X-Frame-Options by fetching the website content
@app.route('/proxy')
def proxy():
    url = request.args.get('url')
    if not url:
        return "No URL provided", 400

    try:
        # Fetch the external content
        response = requests.get(url)
        
        # Remove X-Frame-Options header
        response.headers.pop('X-Frame-Options', None)
        
        # Return the content as-is, but without restrictive headers
        return Response(response.content, content_type=response.headers['Content-Type'])
    except requests.RequestException as e:
        return f"An error occurred: {e}", 500

@app.route('/')
def home():
    return render_template('index.html',lessons=lessons.keys())


@app.route('/lesson/<lesson_name>')
def view_lesson(lesson_name):
    lesson_content = lessons.get(lesson_name, {'text': 'Lesson not found.', 'urls': [], 'video_url': ''})
    content_html = markdown.markdown(lesson_content['text'])
    return render_template('lessons.html', lesson=lesson_name, content=lesson_content, content_html=content_html, video_url=lesson_content['video_url'])


@app.route('/diary_entries')
def diary_entries():
    # Fetch diary files
    diary_files = sorted(os.listdir(DIARY_FOLDER), reverse=True)
    diary_entries = []

    for file in diary_files:
        file_path = os.path.join(DIARY_FOLDER, file)
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        diary_entries.append({'filename': file, 'content': content})

    return render_template('diary_entries.html', diary_entries=diary_entries)


@app.route('/submit-diary', methods=['POST'])
def submit_diary():
    diary_entry = request.form['diary_entry']

    # Use Cohere to analyze the diary entry and suggest a lesson
    response = cohere_client.generate(
        model='command-xlarge-nightly',
        prompt=f"Analyze this diary entry and suggest a moral lesson: {diary_entry} from the following topics only: {', '.join(lessons.keys())}. Return only the topic name without any full stop.",
        max_tokens=100
    )
    lesson_suggestion = response.generations[0].text.strip()

    # Save the diary entry to a text file
    filename = f"{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.txt"
    file_path = os.path.join(DIARY_FOLDER, filename)
    with open(file_path, 'w') as f:
        f.write(diary_entry)
        f.write(f"\n\nLesson Learned: {lesson_suggestion}")

    # Fetch lesson content based on suggestion
    lesson_content = lessons.get(lesson_suggestion, {'text': 'Lesson not found.', 'urls': []})

    lesson_html = markdown.markdown(lesson_content['text'])

    print(lesson_html)
    return render_template('lessons.html', lesson=lesson_suggestion, content_html=lesson_html, content=lesson_content,video_url=lesson_content['video_url'])

if __name__ == '__main__':
    app.run(debug=True)